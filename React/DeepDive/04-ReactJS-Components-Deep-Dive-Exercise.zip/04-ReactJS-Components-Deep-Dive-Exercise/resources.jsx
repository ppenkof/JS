<div className="loading-shade">
  <div className="spinner"></div>

  <div className="table-overlap">
    <svg
      aria-hidden="true"
      focusable="false"
      data-prefix="fas"
      data-icon="triangle-exclamation"
      className="svg-inline--fa fa-triangle-exclamation Table_icon__+HHgn"
      role="img"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512 512"
    >
      <path
        fill="currentColor"
        d="M506.3 417l-213.3-364c-16.33-28-57.54-28-73.98 0l-213.2 364C-10.59 444.9 9.849 480 42.74 480h426.6C502.1 480 522.6 445 506.3 417zM232 168c0-13.25 10.75-24 24-24S280 154.8 280 168v128c0 13.25-10.75 24-23.1 24S232 309.3 232 296V168zM256 416c-17.36 0-31.44-14.08-31.44-31.44c0-17.36 14.07-31.44 31.44-31.44s31.44 14.08 31.44 31.44C287.4 401.9 273.4 416 256 416z"
      ></path>
    </svg>
    <h2>There is no users yet.</h2>
  </div>


  <div className="table-overlap">
    <svg
      aria-hidden="true"
      focusable="false"
      data-prefix="fas"
      data-icon="triangle-exclamation"
      className="svg-inline--fa fa-triangle-exclamation Table_icon__+HHgn"
      role="img"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512 512"
    >
      <path
        fill="currentColor"
        d="M506.3 417l-213.3-364c-16.33-28-57.54-28-73.98 0l-213.2 364C-10.59 444.9 9.849 480 42.74 480h426.6C502.1 480 522.6 445 506.3 417zM232 168c0-13.25 10.75-24 24-24S280 154.8 280 168v128c0 13.25-10.75 24-23.1 24S232 309.3 232 296V168zM256 416c-17.36 0-31.44-14.08-31.44-31.44c0-17.36 14.07-31.44 31.44-31.44s31.44 14.08 31.44 31.44C287.4 401.9 273.4 416 256 416z"
      ></path>
    </svg>
    <h2>Sorry, we couldn't find what you're looking for.</h2>
  </div>


  <div className="table-overlap">
    <svg
      aria-hidden="true"
      focusable="false"
      data-prefix="fas"
      data-icon="triangle-exclamation"
      className="svg-inline--fa fa-triangle-exclamation Table_icon__+HHgn"
      role="img"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512 512"
    >
      <path
        fill="currentColor"
        d="M506.3 417l-213.3-364c-16.33-28-57.54-28-73.98 0l-213.2 364C-10.59 444.9 9.849 480 42.74 480h426.6C502.1 480 522.6 445 506.3 417zM232 168c0-13.25 10.75-24 24-24S280 154.8 280 168v128c0 13.25-10.75 24-23.1 24S232 309.3 232 296V168zM256 416c-17.36 0-31.44-14.08-31.44-31.44c0-17.36 14.07-31.44 31.44-31.44s31.44 14.08 31.44 31.44C287.4 401.9 273.4 416 256 416z"
      ></path>
    </svg>
    <h2>Failed to fetch</h2>
  </div>
</div>

{/* <!-- Create/Edit Form component  --> */ }
<div className="overlay">
  <div className="backdrop"></div>
  <div className="modal">
    <div className="user-container">
      <header className="headers">
        <h2>Edit User/Add User</h2>
        <button className="btn close">
          <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="xmark"
            className="svg-inline--fa fa-xmark" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
            <path fill="currentColor"
              d="M310.6 361.4c12.5 12.5 12.5 32.75 0 45.25C304.4 412.9 296.2 416 288 416s-16.38-3.125-22.62-9.375L160 301.3L54.63 406.6C48.38 412.9 40.19 416 32 416S15.63 412.9 9.375 406.6c-12.5-12.5-12.5-32.75 0-45.25l105.4-105.4L9.375 150.6c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L160 210.8l105.4-105.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-105.4 105.4L310.6 361.4z">
            </path>
          </svg>
        </button>
      </header>
      <form>
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="firstName">First name</label>
            <div className="input-wrapper">
              <span><i className="fa-solid fa-user"></i></span>
              <input id="firstName" name="firstName" type="text" />
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="lastName">Last name</label>
            <div className="input-wrapper">
              <span><i className="fa-solid fa-user"></i></span>
              <input id="lastName" name="lastName" type="text" />
            </div>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <div className="input-wrapper">
              <span><i className="fa-solid fa-envelope"></i></span>
              <input id="email" name="email" type="text" />
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="phoneNumber">Phone number</label>
            <div className="input-wrapper">
              <span><i className="fa-solid fa-phone"></i></span>
              <input id="phoneNumber" name="phoneNumber" type="text" />
            </div>
          </div>
        </div>

        <div className="form-group long-line">
          <label htmlFor="imageUrl">Image Url</label>
          <div className="input-wrapper">
            <span><i className="fa-solid fa-image"></i></span>
            <input id="imageUrl" name="imageUrl" type="text" />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="country">Country</label>
            <div className="input-wrapper">
              <span><i className="fa-solid fa-map"></i></span>
              <input id="country" name="country" type="text" />
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="city">City</label>
            <div className="input-wrapper">
              <span><i className="fa-solid fa-city"></i></span>
              <input id="city" name="city" type="text" />
            </div>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="street">Street</label>
            <div className="input-wrapper">
              <span><i className="fa-solid fa-map"></i></span>
              <input id="street" name="street" type="text" />
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="streetNumber">Street number</label>
            <div className="input-wrapper">
              <span><i className="fa-solid fa-house-chimney"></i></span>
              <input id="streetNumber" name="streetNumber" type="text" />
            </div>
          </div>
        </div>
        <div id="form-actions">
          <button id="action-save" className="btn" type="submit">Save</button>
          <button id="action-cancel" className="btn" type="button">
            Cancel
          </button>
        </div>
      </form>
    </div>
  </div>
</div>


{/* <!-- Delete user component  --> */ }



