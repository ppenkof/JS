export default function Header() {
    return (
        <header className="header">
            <div className="logo">
                <span className="course">React Exercise - Components Deep Dive</span>
            </div>
        </header>
    );
}
