export default function Footer() {
    return (
        <footer className="footer">
            <p>This site is designed to be used for training purposes at SoftUni.</p>
        </footer>
    );
}
