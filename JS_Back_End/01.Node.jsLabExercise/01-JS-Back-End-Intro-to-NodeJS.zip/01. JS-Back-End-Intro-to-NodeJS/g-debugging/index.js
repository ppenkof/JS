import http from 'http';

const server = http.createServer((req, res) => {
    res.write('Hello World');
    res.write('\n');
    res.write('Hello World2');
    res.write('\n');
    res.write('Hello World3');

    res.end();
});

server.listen(5000)
console.log('Server is listening on http://localhost:5000...');
