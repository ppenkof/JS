console.log('Hello, World!');
console.log('This is a sample Node.js application.');

console.log(1);

setTimeout(() => {
    console.log(2);
}, 0);

console.log(3);
