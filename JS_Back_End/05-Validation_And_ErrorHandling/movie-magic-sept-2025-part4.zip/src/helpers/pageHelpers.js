export default {
    setTitle(title) {
        this.pageTitle = title;
    }
}
