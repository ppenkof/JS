export const JWT_SECRET = '89dasfhjo9p0s8dfupqajhashiefh3ruhiawt40dfgas9y78';
