const baseUrl = 'http://localhost:3030';

export const baseUsersUrl = `${baseUrl}/users`;
export const baseStampsUrl = `${baseUrl}/data/stamps`;
export const baseBonusStampsUrl = `${baseUrl}/data/likes`;

